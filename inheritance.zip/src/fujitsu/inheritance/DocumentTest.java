package fujitsu.inheritance;

public class DocumentTest {
	
	public static void main(String[] args) {
		Document d = new Document();
		d.setText("13");
		System.out.println(d.getText());
	}

}
