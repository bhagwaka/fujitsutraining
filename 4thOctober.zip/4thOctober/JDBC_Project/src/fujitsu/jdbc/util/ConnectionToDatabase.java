package fujitsu.jdbc.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class ConnectionToDatabase {
	int student_id;
	String student_name;
	int m1=0;
	int m2=0; 
	int m3=0;
		
	
	public int getStudent_id() {
		return student_id;
	}


	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}


	public String getStudent_name() {
		return student_name;
	}


	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}


	public int getM1() {
		return m1;
	}


	public void setM1(int m1) {
		this.m1 = m1;
	}


	public int getM2() {
		return m2;
	}


	public void setM2(int m2) {
		this.m2 = m2;
	}


	public int getM3() {
		return m3;
	}


	public void setM3(int m3) {
		this.m3 = m3;
	}

	
	@Override
	public String toString() {
		return "ConnectionToDatabase [student_id=" + student_id + ", student_name=" + student_name + ", m1=" + m1
				+ ", m2=" + m2 + ", m3=" + m3 + "]";
	}

	
	static Connection con = null;
	static Connection getConnection(){
	try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con = DriverManager.getConnection("mydbinstance.clfjvtauxahi.ap-south-1.rds.amazonaws.com","fujitsu","password");
		System.out.println("Connection Successful");
	}
	catch(Exception e)
	{
		e.printStackTrace();
		System.out.println("Connection Error!");
	}
	return con;	
	}
		
	
	public static void findAll()
	{
		Connection con = getConnection();
		PreparedStatement psmt;
		try{
			psmt = con.prepareStatement("Select ID,NAME,DEPARTMENT,MARK1,MARK2,MARK3 from Student");
			ResultSet rs = psmt.executeQuery();
			while(rs.next()){
				System.out.println("Student ID:"+rs.getInt("ID"));
				System.out.println("Student Name:"+rs.getInt("NAME"));
				System.out.println("Student Maths:"+rs.getInt("MARK1"));
				System.out.println("Student Science:"+rs.getInt("MARK2"));
				System.out.println("Student English:"+rs.getInt("MARK3"));
			}
		}catch(Exception e){
			System.out.println("Could not find data");
		}	
	}
	
	
	public static void findByID(int id){
		Connection con = getConnection();
		PreparedStatement psmt;
		try{
			psmt = con.prepareStatement("Select ID,NAME from Student where ID=?;");
			psmt.setInt(1,id);
			ResultSet rs = psmt.executeQuery();
			while(rs.next())
			{
				System.out.println("Student Id"+rs.getInt("ID"));
				System.out.println("Student Name"+rs.getInt("NAME"));
			}
		}
		catch(Exception e)
		{
			System.out.println("Error in ID");
		}
 	}
	
	public static void updateData(int id,String name)
	{
		Connection con = getConnection();
		PreparedStatement psmt;
		try {
			psmt = con.prepareStatement("update student set NAME= ? where ID= ?");
			psmt.setString(1,name);
			psmt.setInt(2,id);
			int rs = psmt.executeUpdate();
			System.out.println(rs);
		} catch (Exception e) {
			System.out.println("Error in ID");
		}
	}
	
	public static void deleteData(int id)
	{
		Connection con = getConnection();
		PreparedStatement psmt;
		try {
			psmt = con.prepareStatement("delete from student where ID = ? ");
			psmt.setInt(1,id);
			int rs = psmt.executeUpdate();
			System.out.println(rs);
		} catch (Exception e) {
			System.out.println("Error in ID");
		}
	}
	
	public static void main(String[] args) {
		
		int id = 0;
		String name = "";
		
		getConnection();
		findAll();
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter ID to delete");
		id = scan.nextInt();
		deleteData(id);

		
		System.out.println("Enter ID to Update");
		id = scan.nextInt();
		System.out.println("Enter Name");
		name =  scan.next();
		updateData( id, name);
		
		System.out.println("Enter ID");
		findByID(id);
		
		scan.close();
	}
}