package employee.test;

import java.util.Scanner;

import employee.model.Employee;
import employee.service.EmployeeService;

public class EmployeeTest {
	static Employee employee=new Employee();
	
	public static void main(String[] args) {
		int choice = 0;
		do {
			Scanner scan=new Scanner(System.in);
			System.out.println("\n1. findAll method \n2. PaySlip generation");
			choice = scan.nextInt();
		
			EmployeeService empservice= new EmployeeService();
			switch(choice){
			case 1: 
				empservice.findAll();
			break;
			
			case 2:
				System.out.println("Enter the id you want to Generate report ");
			int id3 = scan.nextInt();
			employee.setEmployee_id(id3);
			empservice.PaySlip(employee);
			break;
			
			case 3: break;
			}
		}while(choice!=3);
		}
		
		}
