package employee.service;

import java.util.List;

import employee.DAO.EmployeeDAO;
import employee.model.Employee;

public class EmployeeService  {
	EmployeeDAO employeeDAO=new EmployeeDAO();
		
	public List<Employee> findAll(){
		return employeeDAO.findAll();
		
	}
	
	public void PaySlip(Employee employee){
		EmployeeDAO.PaySlipGeneration(employee);
	}
}
