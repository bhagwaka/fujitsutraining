package employee.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionUtil {
	static	Connection con=null;
	
	public static Connection getConnection(){
		try{
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/employeedb","root","1234");
		System.out.println("Connection Successfull");
		}
		catch(Exception e){
			e.printStackTrace();
			System.out.println("Connection Failed");
		}
		return con;
	}
		
		
}
