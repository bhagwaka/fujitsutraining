package employee.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import employee.model.Employee;
import employee.util.ConnectionUtil;


public class EmployeeDAO extends ConnectionUtil {

	ArrayList<Employee> employeeList = new ArrayList<Employee>();

	public List<Employee> findAll() {
		Connection con =ConnectionUtil.getConnection();
		
		Statement stmt;
		try{
			stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from Employee");
			while (rs.next()) {
			Employee employee=new Employee();
			employee.setEmployee_id(rs.getInt(1));
			employee.setEmployee_name(rs.getString(2));
			employee.setDepartment(rs.getString(3));
			employee.setBasic_salary(rs.getInt(4));
			employee.setAllowances(rs.getInt(5));
			employee.setTotal_salary(rs.getInt(6));
			employeeList.add(employee);
			System.out.println(""+rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getInt(4)+" "+rs.getInt(5)+" "+rs.getInt(6)+" ");
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return employeeList;

	}

	
	public static void PaySlipGeneration(Employee employee){
		Connection con = ConnectionUtil.getConnection();
		PreparedStatement psmt;
		try {
			psmt = con.prepareStatement(
					"Select * from Employee where id=? ;");
			psmt.setInt(1, employee.getEmployee_id());
			
			ResultSet rs = psmt.executeQuery();
			while (rs.next()) {
				Employee emp= new Employee();
				emp.setEmployee_id(rs.getInt(1));
				emp.setEmployee_name(rs.getString(2));
				emp.setDepartment(rs.getString(3));
				emp.setBasic_salary(rs.getInt(4));
				emp.setAllowances(rs.getInt(5));
				emp.setTotal_salary(rs.getInt(6));
				System.out.println("******************Pay Slip*******************");
				System.out.println(" Id of the Employee is                 :-  "+emp.getEmployee_id());
				System.out.println(" Name of the  Employee is              :-  "+emp.getEmployee_name());
				System.out.println(" Department of the  Employee is        :-  "+emp.getDepartment());
				System.out.println(" Basic Salary is                       :-  "+emp.getBasic_salary());
				System.out.println(" Allowances (HRA,Special ) are         :-  "+emp.getAllowances());
				System.out.println(" Total salary is                       :-  "+emp.getTotal_salary());
				System.out.println("******************End**********************");
			}
		} catch (Exception e) {
			System.out.println("Extraction error in Pay Slip");
		}
		
	}
		
}
