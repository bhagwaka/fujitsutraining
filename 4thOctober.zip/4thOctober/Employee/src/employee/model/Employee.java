package employee.model;

public class Employee {
		int employee_id;
		String employee_name;
		String department;
		int basic_salary;
		int allowances;
		int total_salary;
		public Employee() {
			super();
			
		}
		public Employee(int employee_id, String employee_name, String department, int basic_salary, int allowances,
				int total_salary) {
			super();
			this.employee_id = employee_id;
			this.employee_name = employee_name;
			this.department = department;
			this.basic_salary = basic_salary;
			this.allowances = allowances;
			this.total_salary = total_salary;
		}
		public int getEmployee_id() {
			return employee_id;
		}
		public void setEmployee_id(int employee_id) {
			this.employee_id = employee_id;
		}
		public String getEmployee_name() {
			return employee_name;
		}
		public void setEmployee_name(String employee_name) {
			this.employee_name = employee_name;
		}
		public String getDepartment() {
			return department;
		}
		public void setDepartment(String department) {
			this.department = department;
		}
		public int getBasic_salary() {
			return basic_salary;
		}
		public void setBasic_salary(int basic_salary) {
			this.basic_salary = basic_salary;
		}
		public int getAllowances() {
			return allowances;
		}
		public void setAllowances(int allowances) {
			this.allowances = allowances;
		}
		public int getTotal_salary() {
			return total_salary;
		}
		public void setTotal_salary(int total_salary) {
			this.total_salary = total_salary;
		}
		@Override
		public String toString() {
			return "Employee [employee_id=" + employee_id + ", employee_name=" + employee_name + ", department="
					+ department + ", basic_salary=" + basic_salary + ", allowances=" + allowances + ", total_salary="
					+ total_salary + "]";
		}
		
		
		
		
}
