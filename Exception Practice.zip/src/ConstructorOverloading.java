
public class ConstructorOverloading {
	int a;
	int b;
	int c;

	public  ConstructorOverloading() {

		System.out.println("Contructor 1");
	}

	public ConstructorOverloading(int a, int b) {
		System.out.println("Contructor 2"+"\n"+ (a+b));
		

	}

	public ConstructorOverloading(int a, int b, int c) {
		System.out.println("Contructor 3 "+ "\n"+(a+b+c));
		
	}

	public static void main(String args[]) {
		ConstructorOverloading co1 = new ConstructorOverloading();
		ConstructorOverloading co2 = new ConstructorOverloading(8,8);
		ConstructorOverloading co = new ConstructorOverloading(6,8,8);
  
	}

}
