
public class abc {

	void display_message()
	{
	System.out.println("Outerclass ABC");	
	}
	class pqr{
		void display_message()
		{
			System.out.println("Innerclass PQR");
		}
		class xyz{
			void display_message()
			{
				System.out.println("Innermost class XYZ");
			}
		}
	}
	public static void main(String args[])
	{
		abc.pqr.xyz k = new abc().new pqr().new xyz();
		k.display_message();
			
		abc.pqr l = new abc().new pqr();
		l.display_message();

		abc m = new abc();
		m.display_message();
	}
}
