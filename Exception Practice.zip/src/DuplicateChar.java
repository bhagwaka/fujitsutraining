import java.util.Scanner;

public class DuplicateChar {

	static String st;
	static int counter = 0;
	static char ch;

	void duplicateMethod() {

		for (int i = 0; i < st.length(); i++) {
			if (ch == st.charAt(i)) {
				counter++;
			}

		}
	}

	public static void main(String[] args) {
         
		Scanner sc = new Scanner(System.in);
		DuplicateChar dc=new DuplicateChar();
		System.out.println("Duplicate Character Program");
		
			System.out.println("Enter String.");
			st = sc.next();
			System.out.println("Enter the character you want to count.");
			ch = sc.next().charAt(0);
			dc.duplicateMethod();
			System.out.println("Character " + ch + " count" + counter);
		
	}

}
