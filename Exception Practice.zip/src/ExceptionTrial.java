import java.util.InputMismatchException;
import java.util.Scanner;

public class ExceptionTrial {
	
	void showMessage()
	{
		System.out.println("Something to Show");
	}
	
	public static void main(String[] args) {
		ExceptionTrial exp = null;
		int a = 0;
		int b = 0;
		int c;
		Scanner scan = new Scanner(System.in);	
		
		try{
		int arr[] = new int[5];
		for(int i = 0; i < 7; i++)
		{
			arr[i] = scan.nextInt();
		}
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Array Index Out Of Bounds Exception Occured");
		}
		
		try{
			a = scan.nextInt();
			b = scan.nextInt();
			c = a/b;
			System.out.println("Division is"+c);
		}
		catch (ArithmeticException e) {
			System.out.println("Arithmetic Exception Occured");
		}
		 catch (InputMismatchException e)
		{
			 System.out.println("Input Mismatch Exception Occured");
		}
		
		//2nd try block
		try
		{
			exp.showMessage();
		}
		 catch (NullPointerException e)
		{
			System.out.println("Null Pointer Exception Occured");
		}
		finally
		{
			System.out.println("Finally:- this Will Executed anyhow");
			scan.close();
		}
	}
	
}
